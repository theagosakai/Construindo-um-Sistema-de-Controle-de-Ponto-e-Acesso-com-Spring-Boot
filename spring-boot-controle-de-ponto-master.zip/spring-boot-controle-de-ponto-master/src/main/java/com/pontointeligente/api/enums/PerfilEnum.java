package com.pontointeligente.api.enums;

public enum PerfilEnum {
	
	ROLE_ADMIN,
	ROLE_USUARIO;
	
}
