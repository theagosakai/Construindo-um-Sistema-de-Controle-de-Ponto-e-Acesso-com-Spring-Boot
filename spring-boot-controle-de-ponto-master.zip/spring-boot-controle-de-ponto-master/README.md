[![Build Status](https://travis-ci.org/guilhermerecife/spring-boot-controle-de-ponto.svg?branch=master)](https://travis-ci.org/guilhermerecife/spring-boot-controle-de-ponto)
# API de Ponto Eletrônico